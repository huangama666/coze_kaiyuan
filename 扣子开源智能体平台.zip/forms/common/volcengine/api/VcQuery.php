<?php
/**
 * copyright: Copyright (c)
 */

namespace app\forms\common\volcengine\api;

// https://www.volcengine.com/docs/6561/149749
class VcQuery extends AtaQuery
{
    public function getMethodName()
    {
        return "/api/v1/vc/query?appid=" . $this->api->appid;
    }
}
