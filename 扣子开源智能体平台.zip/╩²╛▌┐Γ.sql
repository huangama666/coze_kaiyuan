-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- 主机： localhost
-- 生成日期： 2025-05-16 15:59:25
-- 服务器版本： 5.7.44-log
-- PHP 版本： 8.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `nicai`
--

-- --------------------------------------------------------

--
-- 表的结构 `wstx_admin_info`
--

CREATE TABLE `wstx_admin_info` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `app_max_count` int(11) NOT NULL DEFAULT '-1' COMMENT '创建小程序最大数量-1.无限制',
  `permissions` text NOT NULL COMMENT '账户权限',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `expired_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '账户过期时间',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0',
  `is_default` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否使用默认权限'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `wstx_admin_info`
--

INSERT INTO `wstx_admin_info` (`id`, `user_id`, `app_max_count`, `permissions`, `remark`, `expired_at`, `is_delete`, `is_default`) VALUES
(1, 1, 0, '[]', '', '0000-00-00 00:00:00', 0, 0),
(2, 2, 0, '[]', '', '0000-00-00 00:00:00', 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `wstx_attachment`
--

CREATE TABLE `wstx_attachment` (
  `id` int(10) UNSIGNED NOT NULL,
  `storage_id` int(11) NOT NULL,
  `attachment_group_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `size` int(11) NOT NULL COMMENT '大小：字节',
  `url` varchar(2080) NOT NULL,
  `thumb_url` varchar(2080) NOT NULL DEFAULT '',
  `type` tinyint(2) NOT NULL COMMENT '类型：1=图片，2=视频',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL,
  `deleted_at` timestamp NOT NULL,
  `is_delete` tinyint(1) NOT NULL DEFAULT '0',
  `is_recycle` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否加入回收站 0.否|1.是'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='附件、文件';

--
-- 转存表中的数据 `wstx_attachment`
--

INSERT INTO `wstx_attachment` (`id`, `storage_id`, `attachment_group_id`, `user_id`, `name`, `size`, `url`, `thumb_url`, `type`, `created_at`, `updated_at`, `deleted_at`, `is_delete`, `is_recycle`) VALUES
(1, 0, 0, 0, 'logo64-64.png', 5176, '/web/uploads/20250420/8d70fad375d441e15ac2048ef88a0a0e.png', '/web/uploads/thumbs/20250420/8d70fad375d441e15ac2048ef88a0a0e.png', 1, '2025-04-20 06:04:58', '2025-04-20 06:04:58', '0000-00-00 00:00:00', 0, 0),
(2, 0, 0, 0, '微信图片_20250203004354.jpg', 56296, '/web/uploads/20250425/a88daf45ff9a9fa3b2ce4be102bedb39.jpg', '/web/uploads/thumbs/20250425/a88daf45ff9a9fa3b2ce4be102bedb39.jpg', 1, '2025-04-24 17:44:09', '2025-04-24 17:44:09', '0000-00-00 00:00:00', 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `wstx_attachment_group`
--

CREATE TABLE `wstx_attachment_group` (
  `id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `is_delete` smallint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `is_recycle` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否加入回收站 0.否|1.是',
  `type` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0 图片 1商品'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- 表的结构 `wstx_attachment_storage`
--

CREATE TABLE `wstx_attachment_storage` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '存储类型：1=本地，2=阿里云，3=腾讯云，4=七牛',
  `config` longtext NOT NULL COMMENT '存储配置',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态：0=未启用，1=已启用',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(11) NOT NULL DEFAULT '1' COMMENT '存储设置所属账号'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='附件存储器';

-- --------------------------------------------------------

--
-- 表的结构 `wstx_av_data`
--

CREATE TABLE `wstx_av_data` (
  `id` int(11) UNSIGNED NOT NULL,
  `file` varchar(255) NOT NULL DEFAULT '' COMMENT '音视频文件',
  `text` text COMMENT '字幕文本',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1:转字幕；2：字幕打轴',
  `job_id` varchar(255) NOT NULL DEFAULT '' COMMENT '任务id',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1:处理中；2：处理完成；3：失败',
  `err_msg` varchar(255) DEFAULT '' COMMENT '失败原因',
  `result` varchar(255) DEFAULT '' COMMENT '最终结果',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL,
  `data` text COMMENT '数据，包括配置等等',
  `account_id` int(10) DEFAULT '0' COMMENT '授权账号'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='音视频处理数据';

-- --------------------------------------------------------

--
-- 表的结构 `wstx_bot_conf`
--

CREATE TABLE `wstx_bot_conf` (
  `id` int(11) UNSIGNED NOT NULL,
  `bot_id` varchar(50) NOT NULL DEFAULT '' COMMENT '智能体ID',
  `version` varchar(50) NOT NULL DEFAULT '' COMMENT '版本号',
  `title` varchar(250) DEFAULT '' COMMENT '智能体名字',
  `icon` varchar(250) DEFAULT '' COMMENT '智能体的显示图标',
  `lang` varchar(50) DEFAULT '' COMMENT '智能体的系统语言',
  `layout` varchar(50) DEFAULT '' COMMENT '智能体窗口的布局风格',
  `is_width` tinyint(1) DEFAULT '1' COMMENT '1: 默认，2：自定义',
  `width` int(10) DEFAULT '0' COMMENT '智能体窗口的宽度',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='coze智能体配置';

--
-- 转存表中的数据 `wstx_bot_conf`
--

INSERT INTO `wstx_bot_conf` (`id`, `bot_id`, `version`, `title`, `icon`, `lang`, `layout`, `is_width`, `width`, `is_delete`, `created_at`, `updated_at`) VALUES
(1, '7494228106061561906', '0.1.0-beta.6', '演示智能体', '/web/uploads/20250420/8d70fad375d441e15ac2048ef88a0a0e.png', 'zh-CN', 'mobile', 1, 1024, 0, '2025-04-20 05:59:46', '2025-05-13 13:45:37'),
(2, '7501869479241121826', '0.1.0-beta.6', '朋友圈智能体', '', 'en', '', 1, NULL, 0, '2025-05-13 13:46:49', '2025-05-13 13:47:03'),
(3, '7503107634905169974', '0.1.0-beta.6', '图片自动微调', '', 'en', 'mobile', 1, NULL, 0, '2025-05-15 03:38:38', '2025-05-15 03:38:38'),
(4, '7496083705392971814', '0.1.0-beta.6', '知识卡片生成', '', 'en', 'mobile', 1, NULL, 0, '2025-05-15 03:40:14', '2025-05-15 03:40:14');

-- --------------------------------------------------------

--
-- 表的结构 `wstx_core_action_log`
--

CREATE TABLE `wstx_core_action_log` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL COMMENT '操作人ID',
  `model` varchar(255) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '模型名称',
  `model_id` int(11) NOT NULL COMMENT '模模型ID',
  `before_update` longtext COLLATE utf8mb4_german2_ci,
  `after_update` longtext COLLATE utf8mb4_german2_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0',
  `remark` varchar(255) COLLATE utf8mb4_german2_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_german2_ci;

-- --------------------------------------------------------

--
-- 表的结构 `wstx_core_exception_log`
--

CREATE TABLE `wstx_core_exception_log` (
  `id` int(11) UNSIGNED NOT NULL,
  `level` tinyint(4) NOT NULL DEFAULT '1' COMMENT '异常等级1.报错|2.警告|3.记录信息',
  `title` mediumtext NOT NULL COMMENT '异常标题',
  `content` mediumtext NOT NULL COMMENT '异常内容',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_delete` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `wstx_core_exception_log`
--

INSERT INTO `wstx_core_exception_log` (`id`, `level`, `title`, `content`, `created_at`, `is_delete`) VALUES
(1, 1, '访问令牌（secret）不正确', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#105: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#69: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#20: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-20 05:03:00', 0),
(2, 1, '访问令牌（secret）不正确', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#105: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#84: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#20: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-20 05:03:06', 0),
(3, 1, '访问令牌（secret）不正确', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#105: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#84: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#20: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-20 05:05:20', 0),
(4, 1, '页面路由未正常配置（会导致员工账号无法进入该页面）,请检查', '[\"#57: \\/forms\\/MenusForm.php\",\"#0: app\\\\controllers\\\\mall\\\\MenusController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-20 05:12:07', 0),
(5, 1, '当前使用的个人访问令牌没有权限访问该资源', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#105: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#97: \\/forms\\/mall\\/setting\\/CozeForm.php\",\"#115: \\/controllers\\/mall\\/IndexController.php\",\"#0: app\\\\controllers\\\\mall\\\\IndexController->actionCozeSpace()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-20 05:20:43', 0),
(6, 1, '当前使用的个人访问令牌没有权限访问该资源', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#105: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#97: \\/forms\\/mall\\/setting\\/CozeForm.php\",\"#115: \\/controllers\\/mall\\/IndexController.php\",\"#0: app\\\\controllers\\\\mall\\\\IndexController->actionCozeSpace()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-20 05:20:57', 0),
(7, 1, '当前使用的个人访问令牌没有权限访问该资源', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#105: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#97: \\/forms\\/mall\\/setting\\/CozeForm.php\",\"#115: \\/controllers\\/mall\\/IndexController.php\",\"#0: app\\\\controllers\\\\mall\\\\IndexController->actionCozeSpace()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-20 05:21:04', 0),
(8, 1, '当前使用的个人访问令牌没有权限访问该资源', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#105: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#97: \\/forms\\/mall\\/setting\\/CozeForm.php\",\"#115: \\/controllers\\/mall\\/IndexController.php\",\"#0: app\\\\controllers\\\\mall\\\\IndexController->actionCozeSpace()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-20 05:21:33', 0),
(9, 1, '当前使用的个人访问令牌没有权限访问该资源', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#105: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#97: \\/forms\\/mall\\/setting\\/CozeForm.php\",\"#115: \\/controllers\\/mall\\/IndexController.php\",\"#0: app\\\\controllers\\\\mall\\\\IndexController->actionCozeSpace()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-20 05:21:57', 0),
(10, 1, '访问令牌（secret）不正确', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#105: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#69: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#20: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-20 05:22:02', 0),
(11, 1, '访问令牌（secret）不正确', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#105: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#84: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#20: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-20 05:22:08', 0),
(12, 1, '访问令牌（secret）不正确', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#105: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#84: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#20: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-20 05:22:16', 0),
(13, 1, 'invalid refresh token: not found', '[\"#45: \\/forms\\/common\\/coze\\/api\\/OauthToken.php\",\"#53: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#67: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#84: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#20: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-20 05:58:09', 0),
(14, 1, '访问令牌（secret）不正确', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#105: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#84: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#20: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-20 05:58:15', 0),
(15, 1, '访问令牌（secret）不正确', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#105: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#84: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#20: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-20 06:07:06', 0),
(16, 1, '访问令牌（secret）不正确', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#105: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#69: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#20: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-20 06:07:11', 0),
(17, 1, '访问令牌（secret）不正确', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#105: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#69: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#20: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-20 06:07:47', 0),
(18, 1, '您提交的数据无法被验证。', '[\"#221: \\/vendor\\/yiisoft\\/yii2\\/web\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-23 18:13:48', 0),
(19, 1, '访问令牌（secret）不正确', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#105: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#69: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#20: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-23 18:14:19', 0),
(20, 1, '您提交的数据无法被验证。', '[\"#221: \\/vendor\\/yiisoft\\/yii2\\/web\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-24 07:48:11', 0),
(21, 1, 'concurrent execute refresh token: YlakW4RRNKdbh0RrwPNMyP7kZszsjAUhiw7IPVUeq30=', '[\"#45: \\/forms\\/common\\/coze\\/api\\/OauthToken.php\",\"#53: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#67: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#84: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#20: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-24 16:03:21', 0),
(22, 1, '访问令牌（secret）不正确', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#105: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#69: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#20: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-24 16:03:43', 0),
(23, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-24 16:38:34', 0),
(24, 1, '访问令牌（secret）不正确', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#105: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#69: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#20: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-24 16:38:34', 0),
(25, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-24 16:38:41', 0),
(26, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-24 16:38:42', 0),
(27, 1, '访问令牌（secret）不正确', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#105: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#69: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#20: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-24 16:38:45', 0),
(28, 1, '访问令牌（secret）不正确', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#105: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#84: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#20: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-24 16:38:51', 0),
(29, 1, '您提交的数据无法被验证。', '[\"#221: \\/vendor\\/yiisoft\\/yii2\\/web\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-24 17:07:02', 0),
(30, 1, 'concurrent execute refresh token: Fx1Q6FAyohsJWxUcdQJ8bwOx1qudoSLN9FgtQyi7U3I=', '[\"#45: \\/forms\\/common\\/coze\\/api\\/OauthToken.php\",\"#53: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#67: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#84: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#20: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-24 17:07:10', 0),
(31, 1, '访问令牌（secret）不正确', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#105: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#69: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#20: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-24 17:07:30', 0),
(32, 1, '访问令牌（secret）不正确', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#104: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#68: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#16: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-24 17:16:56', 0),
(33, 1, '访问令牌（secret）不正确', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#104: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#68: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#16: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-24 17:17:11', 0),
(34, 1, '访问令牌（secret）不正确', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#104: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#83: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#16: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-24 17:19:10', 0),
(35, 1, '访问令牌（secret）不正确', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#104: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#83: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#16: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-24 17:19:11', 0),
(36, 1, 'concurrent execute refresh token: c95iJOI/oTX5UOCzCeLg6oZ3RgNyd8RUSlgdQQLmd+w=', '[\"#44: \\/forms\\/common\\/coze\\/api\\/OauthToken.php\",\"#52: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#66: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#83: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#16: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-24 17:24:16', 0),
(37, 1, '访问令牌（secret）不正确', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#104: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#83: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#16: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-24 17:24:22', 0),
(38, 1, '访问令牌（secret）不正确', '[\"#96: \\/forms\\/common\\/coze\\/Base.php\",\"#104: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#83: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#16: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-24 17:25:35', 0),
(39, 1, 'concurrent execute refresh token: 8C5ppncQDV5H2rbtR+TEEkSfcvS2WxUtlw9EO8R49Jo=', '[\"#43: \\/forms\\/common\\/coze\\/api\\/OauthToken.php\",\"#51: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#65: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#95: \\/forms\\/mall\\/setting\\/CozeForm.php\",\"#108: \\/controllers\\/mall\\/IndexController.php\",\"#0: app\\\\controllers\\\\mall\\\\IndexController->actionCozeSpace()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-24 17:44:41', 0),
(40, 1, 'Undefined variable $res', '[\"#37: \\/forms\\/mall\\/statistics\\/DataForm.php\",\"#37: \\/forms\\/mall\\/statistics\\/DataForm.php\",\"#18: \\/controllers\\/mall\\/StatisticController.php\",\"#0: app\\\\controllers\\\\mall\\\\StatisticController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-24 17:50:30', 0),
(41, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-25 09:01:35', 0),
(42, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-25 09:01:35', 0),
(43, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-25 09:01:36', 0),
(44, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-25 09:01:36', 0),
(45, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-25 09:01:39', 0),
(46, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-25 09:01:39', 0),
(47, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-25 09:01:40', 0),
(48, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-25 09:01:40', 0),
(49, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-25 09:01:41', 0),
(50, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-25 09:01:41', 0),
(51, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-04-28 09:36:01', 0),
(52, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-05 05:55:52', 0),
(53, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-05 05:55:52', 0),
(54, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-05 05:55:54', 0),
(55, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-05 05:55:54', 0),
(56, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-05 05:55:57', 0),
(57, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-05 05:55:57', 0),
(58, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-05 05:55:58', 0),
(59, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-05 05:55:58', 0),
(60, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-05 05:56:00', 0),
(61, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-05 05:56:00', 0),
(62, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-07 11:10:23', 0),
(63, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-07 11:10:24', 0),
(64, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-07 11:10:24', 0),
(65, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-08 08:18:34', 0),
(66, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-08 08:18:34', 0),
(67, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-08 08:18:36', 0),
(68, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-08 08:18:36', 0),
(69, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-08 08:18:40', 0),
(70, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-08 08:18:40', 0),
(71, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-08 08:18:41', 0),
(72, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-08 08:18:41', 0),
(73, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-08 08:18:42', 0),
(74, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-08 08:18:42', 0),
(75, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-09 18:07:00', 0),
(76, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-09 18:07:00', 0),
(77, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-09 18:07:08', 0),
(78, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-09 18:07:08', 0),
(79, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-09 18:07:35', 0),
(80, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-09 18:07:35', 0),
(81, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-09 18:07:41', 0),
(82, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-09 18:07:41', 0),
(83, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-09 18:07:46', 0),
(84, 1, '页面未找到。', '[\"#115: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-09 18:07:46', 0),
(85, 1, 'concurrent execute refresh token: WuxECUoo63wMgXbnmzahr4UVq5kvgs/3Td0y19ozKjI=', '[\"#43: \\/forms\\/common\\/coze\\/api\\/OauthToken.php\",\"#51: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#65: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#95: \\/forms\\/mall\\/setting\\/CozeForm.php\",\"#108: \\/controllers\\/mall\\/IndexController.php\",\"#0: app\\\\controllers\\\\mall\\\\IndexController->actionCozeSpace()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-13 13:45:13', 0),
(86, 1, '访问令牌（secret）不正确', '[\"#94: \\/forms\\/common\\/coze\\/Base.php\",\"#103: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#82: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#16: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-13 13:45:42', 0),
(87, 1, '访问令牌（secret）不正确', '[\"#94: \\/forms\\/common\\/coze\\/Base.php\",\"#103: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#82: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#16: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-13 13:45:48', 0),
(88, 1, '访问令牌（secret）不正确', '[\"#94: \\/forms\\/common\\/coze\\/Base.php\",\"#103: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#82: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#16: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-15 03:33:50', 0),
(89, 1, 'concurrent execute refresh token: G2sRG75JBbI7HWB5GhFS9WalMM1v+BWOwu4nVrVIa6I=', '[\"#43: \\/forms\\/common\\/coze\\/api\\/OauthToken.php\",\"#51: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#65: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#95: \\/forms\\/mall\\/setting\\/CozeForm.php\",\"#108: \\/controllers\\/mall\\/IndexController.php\",\"#0: app\\\\controllers\\\\mall\\\\IndexController->actionCozeSpace()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-15 07:35:21', 0),
(90, 1, '访问令牌（secret）不正确', '[\"#94: \\/forms\\/common\\/coze\\/Base.php\",\"#103: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#82: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#16: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-15 07:35:40', 0),
(91, 1, 'concurrent execute refresh token: TMTCH4ucVGcSs2TPtVtz2jevqejU2sN42DMIcgQ80DY=', '[\"#43: \\/forms\\/common\\/coze\\/api\\/OauthToken.php\",\"#51: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#65: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#95: \\/forms\\/mall\\/setting\\/CozeForm.php\",\"#108: \\/controllers\\/mall\\/IndexController.php\",\"#0: app\\\\controllers\\\\mall\\\\IndexController->actionCozeSpace()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-16 07:33:07', 0),
(92, 1, '访问令牌（secret）不正确', '[\"#94: \\/forms\\/common\\/coze\\/Base.php\",\"#103: \\/forms\\/common\\/coze\\/ApiForm.php\",\"#82: \\/forms\\/mall\\/bot\\/ListForm.php\",\"#16: \\/controllers\\/mall\\/BotController.php\",\"#0: app\\\\controllers\\\\mall\\\\BotController->actionIndex()\",\"#57: \\/vendor\\/yiisoft\\/yii2\\/base\\/InlineAction.php\",\"#178: \\/vendor\\/yiisoft\\/yii2\\/base\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-16 07:33:19', 0),
(93, 1, '您提交的数据无法被验证。', '[\"#221: \\/vendor\\/yiisoft\\/yii2\\/web\\/Controller.php\",\"#552: \\/vendor\\/yiisoft\\/yii2\\/base\\/Module.php\",\"#103: \\/vendor\\/yiisoft\\/yii2\\/web\\/Application.php\",\"#384: \\/vendor\\/yiisoft\\/yii2\\/base\\/Application.php\",\"#13: \\/web\\/index.php\"]', '2025-05-16 07:45:56', 0);

-- --------------------------------------------------------

--
-- 表的结构 `wstx_core_queue`
--

CREATE TABLE `wstx_core_queue` (
  `id` int(11) NOT NULL,
  `channel` varchar(64) NOT NULL,
  `job` blob NOT NULL,
  `pushed_at` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT '0',
  `priority` int(11) UNSIGNED NOT NULL DEFAULT '1024',
  `reserved_at` int(11) DEFAULT NULL,
  `attempt` int(11) DEFAULT NULL,
  `done_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- 表的结构 `wstx_core_session`
--

CREATE TABLE `wstx_core_session` (
  `id` char(40) NOT NULL,
  `expire` int(11) DEFAULT NULL,
  `DATA` blob
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `wstx_core_session`
--

INSERT INTO `wstx_core_session` (`id`, `expire`, `DATA`) VALUES
('085s641raon2ue23s6tcn16no3', 1746777636, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a22726a6a6971223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('0esr2283drk8ipj3k34ht51nt5', 1746972368, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a226f656e6f6b223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('16o53n7vtm3re3u7gaphbpccaq', 1746962845, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a22616a7869223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('1cj85vsif4f4ag248g9tebrf99', 1746691873, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a226b6f776974223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('1hbi95v1ocgdvgi0hbjn0i497q', 1746530342, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a22636d64656b223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('1s7f42sva9ilov1b0oarqndukd', 1746962311, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a226a757672223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('25ue52ig9q8luetajr2c78uua0', 1747155043, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a22747a79656a223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('2nvauddva5mhlkk4cvbec12gjo', 1747298018, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a226b7a6d6e76223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('2o95e7rs31t0e3ef3pa17b3qtq', 1746971338, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a226274737567223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('3g5ph9krqt4agbm567ldkldvmd', 1746962858, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a22727a7161223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('3j678f3um0fc8q4r1lkclhsfn1', 1747282601, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a226c65626f6b223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('3lpbgd9mbi0t3q1a5oeqpio95e', 1746798659, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a226a6f7065223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('3rpe1svk3vvrbot8lvb3rhjqq5', 1746092375, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2270777661223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('3rsojsmispb0mp1apu13afh8bg', 1746399700, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a2276776a6968223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('3thhqj7ud4drcoihjouobiokl7', 1746791479, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a22627179656a223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('4287o5pm21djr5p99naie04e10', 1746404097, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a227861717374223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('509op5d80ffhdbnn843ojuilod', 1746573619, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2272626961223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('5i0a5bsos4hk4fnht5qc74oll8', 1747191080, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a2262726b756c223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('5tbee867u8sq3jsvaifqhrc05o', 1746261545, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a226265767574223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('6kiiudkd6ju0lokj74korbo1e4', 1746395961, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a227478666977223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('6v4cm2muk1ltnemc7sariglljc', 1746975267, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a226165736f223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('73pv72ok5jepkkupc4t5l30hbm', 1746322952, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a226d6961697a223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('75agmbvf3berncnhuek91mg8e1', 1746929386, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a22676d646571223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('7n4llkih6sad77af9ld3vcsptq', 1746345934, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a2273696d736b223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('7qva7ssitknsng6vnqidilro2t', 1746092662, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a22736f6e62223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('83m1kctgb36tfvk6u3mabjrlmo', 1747383006, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a227461796563223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b5f5f69647c693a313b5f5f617574684b65797c733a33323a22474e4e6273576b315a30462d436b67466e4c6432793756583458642d39687245223b),
('86cl19p52a00ojb0ttcr9tura2', 1746929329, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a226e6e6e6978223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('8fqaltviaplon3gcdps4gr8a56', 1746595071, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2262676561223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('8ot8j0tqm7db350b6sd0ohr28t', 1746701222, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a22646f7964223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('8ukvmsqfs07m1hhhbgejlpli4o', 1747382738, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a226b6f63696f223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('9gk2f3qs70r9gfa5rs9d4k9bt2', 1746777685, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a2272756d616d223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('a9noaon5tlbt8st6bijdgorim7', 1746092431, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a22686f786664223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('admonvh42tg1tae9skslhqhfla', 1746395965, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a226669776162223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('ahdr0foa23sm6h1h1ed746h54a', 1746777630, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2272687373223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('ar40acinerrrpr8iokdee2mcu6', 1746322736, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a22626f6a616b223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('b4v11i4rhi56f43krkems9n1vt', 1746887488, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2273656861223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('bufuft0bc2u4p8b6q8ndseeuar', 1747145348, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2269656465223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b5f5f69647c693a313b5f5f617574684b65797c733a33323a22474e4e6273576b315a30462d436b67466e4c6432793756583458642d39687245223b),
('c2bpovph5l12ga6o519t79ibp7', 1746788878, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a226e6e6d61223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('c2uu99n9uh8iochujrl4k0i8o5', 1747281461, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a226b756c6971223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b5f5f69647c693a313b5f5f617574684b65797c733a33323a22474e4e6273576b315a30462d436b67466e4c6432793756583458642d39687245223b),
('c5h2ubqdi4pvkqfd685hjb2cc5', 1746383391, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a227465726962223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('ch6qd9bj02jt914r82jr5h7k7o', 1746468669, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2264756a65223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('cnnav1tbrricfuuc6rps1l87mp', 1747014660, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a226261727a73223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('d9d2gu9l3fl5bsde0fpgfbvsqb', 1746261553, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a226c76797574223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('dlglbcvklvtbmkaeosrjdlucoa', 1746636444, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a227a6f7761223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('e2o9qc5ddqns25cnq3llli237m', 1746650272, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2274657365223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('eajj9dm00450akb96pg76j9fi1', 1746823075, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a22686e796370223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('ebah0bf955vi89qdfiv63ecgov', 1746383338, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a22726f64796c223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('esrjnt7838ifieqb2d5vntodpc', 1746691886, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a226d616a6968223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('f3s63karjn8pftmsptm58pn8r8', 1746399690, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2271667a61223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('f720spkpjk33ae0cqmpo5ge5n9', 1746817623, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a227370636964223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('htc8teknc15hahtjdn87ls2261', 1747148191, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2277736365223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('idgnlpg8ev8ctbrf5d5rj6l7k6', 1747382136, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2264687875223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b5f5f69647c693a313b5f5f617574684b65797c733a33323a22474e4e6273576b315a30462d436b67466e4c6432793756583458642d39687245223b),
('j4mpotbj5qqgcn7bt85mt1dik2', 1746815959, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2269756e75223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('jf3nhp1o1hlap6pc0sca7q7erh', 1746168076, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2270657661223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('k24toougcnh50826e3a74q8rik', 1746650287, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a22697a72656b223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('k85boi7av8l61ahccuj1aootu3', 1746782891, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a22756c786f223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('kfg3eau49r9hl4kdgdpojo9pg7', 1746691821, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2277776869223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('krhk7k2lsj5e185pc1a64p0vn5', 1746636452, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2270777461223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('l1k9fkrfk6895i73rqdak9ofmt', 1746319756, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a226d697a6e65223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('l7a0tggm6fg1acjktkvib9mjgn', 1746822848, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a22766f6e6d223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('led3k3l36vfj04t91nvrnmvc8c', 1746595063, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a227369686979223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('ln9stutdudc5q0516h99gsovfg', 1746261594, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a2278697a756a223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('lojv3et68a7f42t794mm45bn6s', 1746383383, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2277756d7a223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('m442vov6sios8grid4h5vlti32', 1746289401, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a22746f676578223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('m4rbdhjep23vhq13n8gnmlm0ke', 1747382135, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a22636f7a6277223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b5f5f69647c693a313b5f5f617574684b65797c733a33323a22474e4e6273576b315a30462d436b67466e4c6432793756583458642d39687245223b),
('mcv23i25n9212jhe03j16fd3jk', 1746531785, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a226b77716966223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('mqu46cepet52tjehkq12v35mij', 1746161006, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2262757578223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('n77t6t67jrnjfffn1ec0fh45mf', 1746815975, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a226c617075223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('ng979blcg02j641k6lrv48sa70', 1746782916, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2271616375223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('njkc6c7lne119o5fecsevuj4k3', 1746817608, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a226a6f746f223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('nomfu4bj1tu0147rlkcm5uu57m', 1747060932, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a226a6e6c6574223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('nuq972njq64m6vk4h26a95g2d7', 1746289415, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a226b69646b73223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('o70tekiqld2mkbm71iflfmbepc', 1746319747, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2273767565223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('o7hj6kh4b2rgrulci6ekctij59', 1746319785, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a227465777569223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('oak6q8ikja2iiaar4g4hq6q54o', 1747348917, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a226c616c69223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('oec09fcesbr61r8psickfv75qd', 1746285901, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2274657765223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('ojk8e0fdv9a6o2bodiseah0anv', 1746701620, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a227464706f74223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('okhsvmsliesng9nupu6l71h63e', 1746894960, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a226b75797366223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('oqh7o84pptmrg16oucs0ergod7', 1746573561, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a226e75766178223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('oump0k6o7e5us87805jigv6ene', 1746326912, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a2271796d6174223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('oupbpvpdf00ikfkgrqe3eb69br', 1746887474, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a226b656f6c223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('qv057a7192p45ptc2fck7mr7si', 1747151614, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a22696177616a223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('r0i1jjlcd78eo7f36bkgbn62ou', 1746617639, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a226b7a676570223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('r9bebf9iqoja0eooc7g423k5j0', 1746319167, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a226e6163776d223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('rksurj4tlqhuasfjhcb3g8snmk', 1747297886, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a226c786675223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('rtlcs92cab620njoh7torcmqqa', 1746691829, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a227561636f223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('ruh4r6t062a4e94ttuj63l7jmv', 1746092367, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2278656e61223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('s2fh2vm5upktah12iah2g38tbq', 1746168151, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a22676a6a65223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('s9d7gorehcu4r9urnsqd9os0qg', 1746888762, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a226b656d6176223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('sq7djie3e967gb8f71d4svvn0a', 1746783798, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2264616771223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('stuld7l7trprji735hgs9m6rdr', 1746322942, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a2272756f6571223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('th5c3lhunuqpq4oh1i33q6f43c', 1747148178, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2264757a72223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('tkm1o972atikm41db686nlqlqu', 1746788902, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a227a6172756d223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('tltmibammo3hb8apdb1lu5m131', 1746286047, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2277617965223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('tr4ie53l4plg7ibrn9jv84abfj', 1746970542, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2276747475223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('trscme83i7gkm15o0bsipfsg7m', 1746573356, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a2262686d656f223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('u4hv9p5a1kvf6imfuj3vfdo0bd', 1747032870, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a22626961697a223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('udbp9av467cj5fia7lcf6c34j2', 1746269256, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a2262756b6165223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('uefp0v1olsbh5td4r1avp7q81t', 1747191086, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a226f6968656e223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('ukqq0lsnllqdvjb2qb8v887e9n', 1746383348, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a353a2268616c6179223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('upl51ou31sb3jebnfnpqvjvfrj', 1746782930, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2277617765223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b),
('vkeq80783059rt38ec4gnenmjl', 1746962304, 0x5f5f666c6173687c613a303a7b7d5f5f636170746368612f736974652f7069632d636170746368617c733a343a2270656365223b5f5f636170746368612f736974652f7069632d63617074636861636f756e747c693a313b);

-- --------------------------------------------------------

--
-- 表的结构 `wstx_coze_account`
--

CREATE TABLE `wstx_coze_account` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT '',
  `remark` varchar(150) DEFAULT '',
  `coze_secret` varchar(150) NOT NULL DEFAULT '' COMMENT '访问令牌',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `type` tinyint(1) DEFAULT '1' COMMENT '1：个人令牌；2：OAuth',
  `client_id` varchar(64) DEFAULT '' COMMENT '客户端id',
  `client_secret` varchar(64) DEFAULT '' COMMENT '客户端密钥',
  `expires_in` int(10) DEFAULT NULL COMMENT '访问令牌过期时间',
  `refresh_token` varchar(150) DEFAULT '' COMMENT '刷新令牌'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='coze授权账号';

--
-- 转存表中的数据 `wstx_coze_account`
--

INSERT INTO `wstx_coze_account` (`id`, `name`, `remark`, `coze_secret`, `is_delete`, `created_at`, `updated_at`, `deleted_at`, `type`, `client_id`, `client_secret`, `expires_in`, `refresh_token`) VALUES
(1, 'huangama', NULL, 'czu_lSL0ELHp41MctBG6InSAfA2v2ZT1eurQGHClzgr2F0PQ9ljVG7sx0B3wBoNR4Q7Wb', 1, '2025-04-20 05:02:51', '2025-04-20 05:06:59', '2025-04-20 05:06:59', 2, '61402158303435399016444349759568.app.coze', 'ghH1hniucTPK8QGcFmmOa6qHl1ABdRXg9OttGTOEaaQY4HXw', 1745126271, 'Rg1xlIN7jpY33kpbzFhpBQvJtlf8k1exG9nu0wP1rTZDF27T2fT8prxea2jCiu8jfWipWOOK'),
(2, 'Secret1', '', 'pat_PSsaD8RatU1cow3NheAyGgjA2BvaNBfOwwQZUxQXKgCvpZRzgzdLgEHhNL2HNGY6', 1, '2025-04-20 05:07:06', '2025-04-20 05:16:41', '2025-04-20 05:16:41', 1, '', '', NULL, ''),
(3, 'dayede', NULL, 'czu_qoXV7oyQKG3OTjhqRmIODnJfb8Jl5lKaOywnkiy7LtgqCozaCVTYlLPfSGHXSzrCj', 1, '2025-04-20 05:20:38', '2025-05-16 07:43:17', '2025-05-16 07:43:17', 2, '23406258853881351840195133921199.app.coze', 'AL6t7d9qPOhGghhvZwm6zdta0AVgCsZ9TkPuGubjeEpGnvP8', 1747381687, 'PVydKJffhpf1jHeoOc5TQ28rewZW0FyC4CyJ6EJbZZMYOfXByGuyYkITenFpniN5CQBInXnG');

-- --------------------------------------------------------

--
-- 表的结构 `wstx_knowledge`
--

CREATE TABLE `wstx_knowledge` (
  `id` int(11) UNSIGNED NOT NULL,
  `dataset_id` varchar(100) NOT NULL DEFAULT '' COMMENT '知识库ID',
  `name` varchar(100) DEFAULT '',
  `desc` varchar(255) DEFAULT '' COMMENT '描述',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `format_type` tinyint(1) DEFAULT NULL COMMENT '0：文档类型；1：表格类型；2：照片类型',
  `account_id` int(10) DEFAULT '0' COMMENT '授权账号',
  `space_id` varchar(32) DEFAULT '0' COMMENT '所属空间',
  `num` int(10) DEFAULT '0' COMMENT '文件数量'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='扣子知识库';

-- --------------------------------------------------------

--
-- 表的结构 `wstx_option`
--

CREATE TABLE `wstx_option` (
  `id` int(11) NOT NULL,
  `group` varchar(100) NOT NULL DEFAULT '',
  `name` varchar(150) NOT NULL,
  `value` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

--
-- 转存表中的数据 `wstx_option`
--

INSERT INTO `wstx_option` (`id`, `group`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, '', 'version', '\"1.0.7\"', '2025-04-20 04:59:57', '0000-00-00 00:00:00'),
(2, '', 'coze_web_sdk', '{\"bot_id\":\"7496083705392971814\",\"account_id\":null,\"space_id\":null}', '2025-04-20 05:58:30', '2025-05-15 03:40:14'),
(3, 'admin', 'ind_setting', '{\"name\":\"黄啊码-开源智能体平台\",\"mall_logo_pic\":\"https:\\/\\/coze.xuehaier.com\\/web\\/uploads\\/20250425\\/a88daf45ff9a9fa3b2ce4be102bedb39.jpg\",\"passport_logo\":\"https:\\/\\/coze.xuehaier.com\\/web\\/uploads\\/20250420\\/8d70fad375d441e15ac2048ef88a0a0e.png\",\"passport_bg\":\"https:\\/\\/coze.xuehaier.com\\/web\\/statics\\/img\\/admin\\/BG.png\",\"copyright\":\"Powered by 金脉全域数科\",\"copyright_url\":\"你家的网址，好好想想？\",\"version_text\":\"开源版本完全免费开源使用\",\"voice_text\":\"\"}', '2025-04-20 06:05:27', '2025-05-16 07:42:58');

-- --------------------------------------------------------

--
-- 表的结构 `wstx_user`
--

CREATE TABLE `wstx_user` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL,
  `password` varchar(128) NOT NULL,
  `nickname` varchar(100) NOT NULL DEFAULT '',
  `auth_key` varchar(128) NOT NULL,
  `access_token` varchar(128) NOT NULL,
  `mobile` varchar(255) NOT NULL DEFAULT '',
  `unionid` varchar(64) NOT NULL DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `wstx_user`
--

INSERT INTO `wstx_user` (`id`, `username`, `password`, `nickname`, `auth_key`, `access_token`, `mobile`, `unionid`, `created_at`, `updated_at`, `deleted_at`, `is_delete`) VALUES
(1, 'admin', '$2y$13$laD/Xv4CoyJcMyngHXKpY.DtJN4V4RPWifgR77KA/y2auPu/vfpwG', 'admin', 'GNNbsWk1Z0F-CkgFnLd2y7VX4Xd-9hrE', 'FxFANWYttLdQ49wgmO2cdl16lletCgyd', '', '', '2025-04-20 04:59:55', '2025-05-16 07:45:39', '0000-00-00 00:00:00', 0),
(2, 'admin2', '$2y$13$oqy3eBz4QV723xsKSAFBTeIbwlI9bNQuEriYiqZDw/JGtP4VkjJQe', 'admin2', 'GNNbsWk1Z0F-CkgFnLd2y7VX4Xd-9hrE', 'FxFANWYttLdQ49wgmO2cdl16lletCgyd', '', '', '2025-04-20 04:59:55', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- 表的结构 `wstx_user_identity`
--

CREATE TABLE `wstx_user_identity` (
  `id` int(11) UNSIGNED NOT NULL COMMENT '用户身份表',
  `user_id` int(11) NOT NULL,
  `is_super_admin` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否为超级管理员',
  `is_admin` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否为管理员',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `wstx_user_identity`
--

INSERT INTO `wstx_user_identity` (`id`, `user_id`, `is_super_admin`, `is_admin`, `is_delete`) VALUES
(1, 1, 1, 0, 0),
(2, 2, 0, 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `wstx_user_info`
--

CREATE TABLE `wstx_user_info` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `avatar` varchar(255) NOT NULL DEFAULT '' COMMENT '头像',
  `platform_user_id` varchar(255) NOT NULL DEFAULT '' COMMENT '用户所属平台的用户id',
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额',
  `total_balance` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '总余额',
  `is_blacklist` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否黑名单',
  `contact_way` varchar(255) NOT NULL DEFAULT '' COMMENT '联系方式',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0',
  `remark_name` varchar(60) NOT NULL DEFAULT '' COMMENT '备注名'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- 表的结构 `wstx_volcengine_account`
--

CREATE TABLE `wstx_volcengine_account` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT '',
  `app_id` varchar(20) NOT NULL DEFAULT '' COMMENT 'APP ID',
  `access_token` varchar(100) NOT NULL DEFAULT '' COMMENT 'Access Token',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='火山引擎应用账号';

-- --------------------------------------------------------

--
-- 表的结构 `wstx_volcengine_keys`
--

CREATE TABLE `wstx_volcengine_keys` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT '',
  `access_id` varchar(50) NOT NULL DEFAULT '' COMMENT 'Access Key ID',
  `secret_key` varchar(100) NOT NULL DEFAULT '' COMMENT 'Secret Access Key',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='火山引擎密钥';

-- --------------------------------------------------------

--
-- 表的结构 `wstx_volcengine_keys_relation`
--

CREATE TABLE `wstx_volcengine_keys_relation` (
  `id` int(11) UNSIGNED NOT NULL,
  `key_id` int(11) NOT NULL COMMENT '密钥id',
  `account_id` int(11) NOT NULL COMMENT '应用id',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='密钥与账号关联表';

--
-- 转储表的索引
--

--
-- 表的索引 `wstx_admin_info`
--
ALTER TABLE `wstx_admin_info`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `is_delete` (`is_delete`);

--
-- 表的索引 `wstx_attachment`
--
ALTER TABLE `wstx_attachment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `attachment_group_id` (`attachment_group_id`),
  ADD KEY `type` (`type`),
  ADD KEY `is_delete` (`is_delete`),
  ADD KEY `is_recycle` (`is_recycle`);

--
-- 表的索引 `wstx_attachment_group`
--
ALTER TABLE `wstx_attachment_group`
  ADD PRIMARY KEY (`id`),
  ADD KEY `type` (`type`);

--
-- 表的索引 `wstx_attachment_storage`
--
ALTER TABLE `wstx_attachment_storage`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `wstx_av_data`
--
ALTER TABLE `wstx_av_data`
  ADD PRIMARY KEY (`id`),
  ADD KEY `type` (`type`),
  ADD KEY `status` (`status`),
  ADD KEY `is_delete` (`is_delete`);

--
-- 表的索引 `wstx_bot_conf`
--
ALTER TABLE `wstx_bot_conf`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bot_id` (`bot_id`),
  ADD KEY `is_delete` (`is_delete`);

--
-- 表的索引 `wstx_core_action_log`
--
ALTER TABLE `wstx_core_action_log`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `wstx_core_exception_log`
--
ALTER TABLE `wstx_core_exception_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `is_delete` (`is_delete`);

--
-- 表的索引 `wstx_core_queue`
--
ALTER TABLE `wstx_core_queue`
  ADD PRIMARY KEY (`id`),
  ADD KEY `channel` (`channel`),
  ADD KEY `reserved_at` (`reserved_at`),
  ADD KEY `priority` (`priority`);

--
-- 表的索引 `wstx_core_session`
--
ALTER TABLE `wstx_core_session`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `wstx_coze_account`
--
ALTER TABLE `wstx_coze_account`
  ADD PRIMARY KEY (`id`),
  ADD KEY `is_delete` (`is_delete`);

--
-- 表的索引 `wstx_knowledge`
--
ALTER TABLE `wstx_knowledge`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dataset_id` (`dataset_id`),
  ADD KEY `is_delete` (`is_delete`),
  ADD KEY `account_id` (`account_id`);

--
-- 表的索引 `wstx_option`
--
ALTER TABLE `wstx_option`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `group` (`group`);

--
-- 表的索引 `wstx_user`
--
ALTER TABLE `wstx_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`),
  ADD KEY `access_token` (`access_token`);

--
-- 表的索引 `wstx_user_identity`
--
ALTER TABLE `wstx_user_identity`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `is_super_admin` (`is_super_admin`);

--
-- 表的索引 `wstx_user_info`
--
ALTER TABLE `wstx_user_info`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `platform_user_id` (`platform_user_id`);

--
-- 表的索引 `wstx_volcengine_account`
--
ALTER TABLE `wstx_volcengine_account`
  ADD PRIMARY KEY (`id`),
  ADD KEY `is_delete` (`is_delete`);

--
-- 表的索引 `wstx_volcengine_keys`
--
ALTER TABLE `wstx_volcengine_keys`
  ADD PRIMARY KEY (`id`),
  ADD KEY `is_delete` (`is_delete`);

--
-- 表的索引 `wstx_volcengine_keys_relation`
--
ALTER TABLE `wstx_volcengine_keys_relation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `is_delete` (`is_delete`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `wstx_admin_info`
--
ALTER TABLE `wstx_admin_info`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- 使用表AUTO_INCREMENT `wstx_attachment`
--
ALTER TABLE `wstx_attachment`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- 使用表AUTO_INCREMENT `wstx_attachment_group`
--
ALTER TABLE `wstx_attachment_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `wstx_attachment_storage`
--
ALTER TABLE `wstx_attachment_storage`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `wstx_av_data`
--
ALTER TABLE `wstx_av_data`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `wstx_bot_conf`
--
ALTER TABLE `wstx_bot_conf`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- 使用表AUTO_INCREMENT `wstx_core_action_log`
--
ALTER TABLE `wstx_core_action_log`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `wstx_core_exception_log`
--
ALTER TABLE `wstx_core_exception_log`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;

--
-- 使用表AUTO_INCREMENT `wstx_core_queue`
--
ALTER TABLE `wstx_core_queue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `wstx_coze_account`
--
ALTER TABLE `wstx_coze_account`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 使用表AUTO_INCREMENT `wstx_knowledge`
--
ALTER TABLE `wstx_knowledge`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `wstx_option`
--
ALTER TABLE `wstx_option`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 使用表AUTO_INCREMENT `wstx_user`
--
ALTER TABLE `wstx_user`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- 使用表AUTO_INCREMENT `wstx_user_identity`
--
ALTER TABLE `wstx_user_identity`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '用户身份表', AUTO_INCREMENT=3;

--
-- 使用表AUTO_INCREMENT `wstx_user_info`
--
ALTER TABLE `wstx_user_info`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `wstx_volcengine_account`
--
ALTER TABLE `wstx_volcengine_account`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `wstx_volcengine_keys`
--
ALTER TABLE `wstx_volcengine_keys`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `wstx_volcengine_keys_relation`
--
ALTER TABLE `wstx_volcengine_keys_relation`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
