<?php


namespace app\controllers\mall;

class MaterialController extends AdminController
{
    public function actionIndex()
    {
        if (\Yii::$app->request->isAjax) {

        } else {
            return $this->render('index');
        }
    }
}