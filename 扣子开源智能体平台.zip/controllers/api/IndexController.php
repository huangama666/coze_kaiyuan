<?php
/**
 * 
 * Created by IntelliJ IDEA
 */

namespace app\controllers\api;

class IndexController extends ApiController
{
    public function behaviors()
    {
        return array_merge(parent::behaviors(), [
        ]);
    }
}
