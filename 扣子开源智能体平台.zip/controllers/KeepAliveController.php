<?php


namespace app\controllers;

use app\controllers\mall\behaviors\LoginFilter;

class KeepAliveController extends Controller
{
    public function behaviors()
    {
        return array_merge(parent::behaviors(), [
            'loginFilter' => [
                'class' => LoginFilter::class,
            ],
        ]);
    }

    public function actionIndex()
    {
    }
}
