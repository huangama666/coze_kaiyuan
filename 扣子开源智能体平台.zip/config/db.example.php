<?php

return [
    'host' => '127.0.0.1',
    'port' => 3306,
    'dbname' => 'wstx_mall',
    'username' => 'wstx_mall',
    'password' => '123456',
    'tablePrefix' => 'hjmall_',
];
