<?php

return [
    'host' => '127.0.0.1',
    'port' => 3306,
    'dbname' => 'nicai',
    'username' => 'nicai',
    'password' => 'nicai',
    'tablePrefix' => 'wstx_',
];
