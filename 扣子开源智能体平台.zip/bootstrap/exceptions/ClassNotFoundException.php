<?php
/**
 * Created by IntelliJ IDEA.
 * Date: 2019/3/5
 * Time: 14:14
 */

namespace app\bootstrap\exceptions;


class ClassNotFoundException extends \Exception
{

}
