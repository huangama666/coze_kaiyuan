<?php


namespace app\handlers;

use yii\base\BaseObject;

class HandlerRegister extends BaseObject
{
    public function getHandlers()
    {
        return [
            MyHandler::class,
        ];
    }
}
